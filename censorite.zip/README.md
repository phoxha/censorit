# ng-todo
Minimal angular todo extension for Chrome

This is live example of tutorial:

Grab it from chrome webstore: https://chrome.google.com/webstore/detail/aommafigioodamhobgffifgoonmpnmmc
