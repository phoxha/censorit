chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
var keywords = JSON.parse(request.args);
        keywords.forEach(function(entry) {
            if(!entry.completed)
            {
                            //as user provided it
                            $(':contains('+entry.content+'):not(:has(*))').hide();
                            $("img[alt*='"+entry.content+"']").hide();
                            $('img[src*="'+entry.content+'"]').hide();
                            $('a[href*="'+entry.content+'"]').hide();
                            $("p:contains('"+entry.content+"')" ).hide();
                            $("u:contains('"+entry.content+"')" ).hide();
                            $("li:contains('"+entry.content+"')" ).hide();
                            $("a:contains('"+entry.content+"')" ).hide();
                            $("li:contains('"+entry.content+"')" ).hide();

                            //to lower case
                             $(':contains('+entry.content.toLowerCase()+'):not(:has(*))').hide();
                            $("img[alt*='"+entry.content.toLowerCase()+"']").hide();
                            $('img[src*="'+entry.content.toLowerCase()+'"]').hide();
                            $('a[href*="'+entry.content.toLowerCase()+'"]').hide();
                            $("p:contains('"+entry.content.toLowerCase()+"')" ).hide();
                            $("u:contains('"+entry.content.toLowerCase()+"')" ).hide();
                            $("li:contains('"+entry.content.toLowerCase()+"')" ).hide();
                            $("a:contains('"+entry.content.toLowerCase()+"')" ).hide();
                            $("li:contains('"+entry.content.toLowerCase()+"')" ).hide();

                            
            }

            
            
        });
     
});
